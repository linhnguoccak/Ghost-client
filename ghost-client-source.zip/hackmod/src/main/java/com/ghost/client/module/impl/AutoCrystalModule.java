package com.ghost.client.module.impl;

import com.ghost.client.module.Module;
import com.ghost.client.module.config.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.explosion.Explosion;

import java.util.ArrayList;
import java.util.List;

public class AutoCrystalModule extends Module {

    // --- settings ---
    public final Setting<Double> placeRange = new Setting<>(
        "Place Range", "Max distance to place crystal", 4.0, 1.0, 6.0);
    public final Setting<Double> breakRange = new Setting<>(
        "Break Range", "Max distance to break crystal", 5.0, 1.0, 7.0);
    public final Setting<Double> minDamage = new Setting<>(
        "Min Damage", "Minimum damage to target before placing", 6.0, 1.0, 20.0);
    public final Setting<Double> maxSelfDamage = new Setting<>(
        "Max Self Dmg", "Maximum self-damage allowed", 8.0, 1.0, 20.0);
    public final Setting<Integer> delay = new Setting<>(
        "Delay (ticks)", "Ticks between actions", 0, 0, 10);
    public final Setting<Boolean> rotate = new Setting<>(
        "Rotate", "Rotate towards target silently", true);
    public final Setting<Boolean> antiSuicide = new Setting<>(
        "Anti Suicide", "Stop if self-damage exceeds health", true);

    private int tickCount = 0;

    public AutoCrystalModule() {
        super("AutoCrystal", "Automatically places and breaks end crystals", Category.COMBAT);
        settings.add(placeRange);
        settings.add(breakRange);
        settings.add(minDamage);
        settings.add(maxSelfDamage);
        settings.add(delay);
        settings.add(rotate);
        settings.add(antiSuicide);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        tickCount++;
        if (tickCount < delay.getValue()) return;
        tickCount = 0;

        // switch to crystal if not holding
        boolean holdingCrystal = mc.player.getMainHandStack().isOf(Items.END_CRYSTAL);
        if (!holdingCrystal) {
            int slot = findCrystalSlot();
            if (slot == -1) return;
            mc.player.getInventory().selectedSlot = slot;
            return;
        }

        PlayerEntity target = findTarget();
        if (target == null) return;

        // 1) break existing crystals near target
        breakNearestCrystal(target);

        // 2) place crystal on best block near target
        placeCrystal(target);
    }

    private void breakNearestCrystal(PlayerEntity target) {
        double rangeBreak = breakRange.getValue();
        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof EndCrystalEntity)) continue;
            if (mc.player.distanceTo(e) > rangeBreak) continue;
            mc.interactionManager.attackEntity(mc.player, e);
            mc.player.swingHand(Hand.MAIN_HAND);
            return;
        }
    }

    private void placeCrystal(PlayerEntity target) {
        double rangePl = placeRange.getValue();
        Vec3d targetPos = target.getPos();
        BlockPos best = null;
        double bestScore = -1;

        for (int x = (int)(targetPos.x - 3); x <= targetPos.x + 3; x++) {
            for (int z = (int)(targetPos.z - 3); z <= targetPos.z + 3; z++) {
                BlockPos pos = new BlockPos(x, (int) targetPos.y - 1, z);
                if (!isValidPlacement(pos)) continue;
                if (mc.player.getPos().distanceTo(new Vec3d(x + 0.5, pos.getY() + 1.5, z + 0.5)) > rangePl) continue;

                double dmgTarget = calcExplosionDamage(target, pos.up());
                double dmgSelf   = calcExplosionDamage(mc.player, pos.up());

                if (dmgTarget < minDamage.getValue()) continue;
                if (dmgSelf > maxSelfDamage.getValue()) continue;
                if (antiSuicide.getValue() && dmgSelf >= mc.player.getHealth()) continue;

                double score = dmgTarget - dmgSelf;
                if (score > bestScore) {
                    bestScore = score;
                    best = pos;
                }
            }
        }

        if (best == null) return;

        BlockHitResult hitResult = new BlockHitResult(
            new Vec3d(best.getX() + 0.5, best.getY() + 1.0, best.getZ() + 0.5),
            Direction.UP, best, false
        );
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
    }

    private boolean isValidPlacement(BlockPos pos) {
        if (mc.world == null) return false;
        // block below must be solid, space above must be empty
        boolean solidBelow = !mc.world.getBlockState(pos).isAir();
        boolean emptyAbove = mc.world.getBlockState(pos.up()).isAir();
        boolean emptyAbove2 = mc.world.getBlockState(pos.up().up()).isAir();
        // no crystal already there
        Box checkBox = new Box(pos.up());
        boolean noCrystal = mc.world.getEntitiesByClass(EndCrystalEntity.class, checkBox, e -> true).isEmpty();
        return solidBelow && emptyAbove && emptyAbove2 && noCrystal;
    }

    // simplified explosion damage estimate (not perfect, good enough for targeting)
    private double calcExplosionDamage(Entity entity, BlockPos origin) {
        Vec3d ePos  = entity.getPos().add(0, entity.getHeight() / 2.0, 0);
        Vec3d oPos  = new Vec3d(origin.getX() + 0.5, origin.getY() + 0.5, origin.getZ() + 0.5);
        double dist = ePos.distanceTo(oPos);
        double power = 6.0; // end crystal power
        if (dist > power) return 0;
        double impact = (1.0 - dist / power) * power * 2;
        // rough armor reduction ~50%
        return impact * 0.5;
    }

    private PlayerEntity findTarget() {
        double range = Math.max(placeRange.getValue(), breakRange.getValue());
        PlayerEntity closest = null;
        double closestDist = Double.MAX_VALUE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            double d = mc.player.distanceTo(p);
            if (d < range && d < closestDist) {
                closestDist = d;
                closest = p;
            }
        }
        return closest;
    }

    private int findCrystalSlot() {
        for (int i = 0; i < 9; i++) {
            if (mc.player.getInventory().getStack(i).isOf(Items.END_CRYSTAL)) return i;
        }
        return -1;
    }
}
