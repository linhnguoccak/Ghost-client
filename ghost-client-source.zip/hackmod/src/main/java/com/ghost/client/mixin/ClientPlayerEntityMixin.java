package com.ghost.client.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;

// placeholder — extend here if per-tick player logic needs mixin hooks
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {
}
