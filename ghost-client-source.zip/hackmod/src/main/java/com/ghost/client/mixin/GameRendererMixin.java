package com.ghost.client.mixin;

import com.ghost.client.GhostClient;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "render", at = @At("HEAD"))
    private void ghost_onRender(CallbackInfo ci) {
        // render hook — ClickGUI draws via Screen, not here
        // extend for ESP / other render features
    }
}
