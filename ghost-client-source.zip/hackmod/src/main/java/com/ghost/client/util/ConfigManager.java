package com.ghost.client.util;

import com.ghost.client.GhostClient;
import com.ghost.client.module.Module;
import com.ghost.client.module.config.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Simple JSON config — hand-rolled to avoid pulling in Gson dependency.
 * Format per module:
 * {
 *   "AutoCrystal": {
 *     "enabled": true,
 *     "Place Range": 4.0,
 *     "Min Damage": 6.0
 *   },
 *   ...
 * }
 */
public class ConfigManager {

    private static final String CONFIG_FILE = "ghost-client.json";
    private final Path configPath;

    public ConfigManager() {
        configPath = FabricLoader.getInstance()
            .getConfigDir()
            .resolve(CONFIG_FILE);
    }

    // ── save ──────────────────────────────────────────────────────────────────

    public void save() {
        StringBuilder sb = new StringBuilder("{\n");
        List<Module> modules = GhostClient.getModuleManager().getModules();
        for (int mi = 0; mi < modules.size(); mi++) {
            Module m = modules.get(mi);
            sb.append("  \"").append(escape(m.getName())).append("\": {\n");
            sb.append("    \"enabled\": ").append(m.isEnabled());
            for (Setting<?> s : m.getSettings()) {
                sb.append(",\n    \"").append(escape(s.getName())).append("\": ");
                Object v = s.getValue();
                if (v instanceof Boolean) sb.append(v);
                else if (v instanceof Number) sb.append(v);
                else sb.append("\"").append(escape(v.toString())).append("\"");
            }
            sb.append("\n  }");
            if (mi < modules.size() - 1) sb.append(",");
            sb.append("\n");
        }
        sb.append("}\n");

        try {
            Files.writeString(configPath, sb.toString());
        } catch (IOException e) {
            GhostClient.LOGGER.error("[Ghost] Failed to save config: {}", e.getMessage());
        }
    }

    // ── load ──────────────────────────────────────────────────────────────────

    public void load() {
        if (!Files.exists(configPath)) return;
        try {
            String raw = Files.readString(configPath);
            for (Module m : GhostClient.getModuleManager().getModules()) {
                String block = extractBlock(raw, m.getName());
                if (block == null) continue;

                Boolean enabled = readBool(block, "enabled");
                if (enabled != null) m.setEnabled(enabled);

                for (Setting<?> s : m.getSettings()) {
                    Object v = s.getValue();
                    if (v instanceof Boolean) {
                        Boolean bv = readBool(block, s.getName());
                        if (bv != null) s.setValueRaw(bv);
                    } else if (v instanceof Number) {
                        Double dv = readDouble(block, s.getName());
                        if (dv != null) s.setValueRaw(dv);
                    }
                }
            }
        } catch (IOException e) {
            GhostClient.LOGGER.error("[Ghost] Failed to load config: {}", e.getMessage());
        }
    }

    // ── tiny JSON parser helpers ───────────────────────────────────────────────

    /** Extract the inner {...} block for a given module name. */
    private String extractBlock(String json, String moduleName) {
        String key = "\"" + moduleName + "\"";
        int ki = json.indexOf(key);
        if (ki == -1) return null;
        int open = json.indexOf('{', ki + key.length());
        if (open == -1) return null;
        int depth = 0, i = open;
        while (i < json.length()) {
            char c = json.charAt(i);
            if (c == '{') depth++;
            else if (c == '}') { depth--; if (depth == 0) return json.substring(open, i + 1); }
            i++;
        }
        return null;
    }

    private Boolean readBool(String block, String key) {
        String k = "\"" + key + "\"";
        int ki = block.indexOf(k);
        if (ki == -1) return null;
        int colon = block.indexOf(':', ki + k.length());
        if (colon == -1) return null;
        String rest = block.substring(colon + 1).trim();
        if (rest.startsWith("true"))  return true;
        if (rest.startsWith("false")) return false;
        return null;
    }

    private Double readDouble(String block, String key) {
        String k = "\"" + key + "\"";
        int ki = block.indexOf(k);
        if (ki == -1) return null;
        int colon = block.indexOf(':', ki + k.length());
        if (colon == -1) return null;
        String rest = block.substring(colon + 1).trim();
        StringBuilder num = new StringBuilder();
        for (char c : rest.toCharArray()) {
            if (Character.isDigit(c) || c == '.' || c == '-') num.append(c);
            else break;
        }
        try { return Double.parseDouble(num.toString()); } catch (NumberFormatException e) { return null; }
    }

    private String escape(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
