package com.ghost.client.module.impl;

import com.ghost.client.module.Module;
import com.ghost.client.module.config.Setting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.item.ItemStack;

public class AutoTotemModule extends Module {

    public final Setting<Double> healthThreshold = new Setting<>(
        "Health Threshold", "Auto-equip totem when health drops below this", 16.0, 1.0, 20.0);
    public final Setting<Boolean> offHandOnly = new Setting<>(
        "Offhand Only", "Only place totem in offhand slot", true);

    public AutoTotemModule() {
        super("AutoTotem", "Automatically keeps a totem in your offhand", Category.PLAYER);
        settings.add(healthThreshold);
        settings.add(offHandOnly);
    }

    @Override
    public void onTick() {
        if (mc.player == null) return;

        ClientPlayerEntity p = mc.player;
        float hp = p.getHealth();

        boolean needTotem = hp <= healthThreshold.getValue()
            || !p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);

        if (!needTotem) return;
        if (p.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        // find totem in hotbar or inventory (slots 0-35)
        int totemSlot = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack stack = p.getInventory().getStack(i);
            if (stack.isOf(Items.TOTEM_OF_UNDYING)) {
                totemSlot = i;
                break;
            }
        }
        if (totemSlot == -1) return;

        // swap to offhand via container slot click
        // offhand slot in survival inventory = slot 45
        int containerSlot = totemSlot < 9
            ? totemSlot + 36   // hotbar → container slots 36-44
            : totemSlot;       // inventory → container slots 9-35

        // pick up totem
        mc.interactionManager.clickSlot(
            p.currentScreenHandler.syncId,
            containerSlot, 0, SlotActionType.PICKUP, p);
        // place in offhand (slot 45)
        mc.interactionManager.clickSlot(
            p.currentScreenHandler.syncId,
            45, 0, SlotActionType.PICKUP, p);
        // return leftover stack (if any) back
        mc.interactionManager.clickSlot(
            p.currentScreenHandler.syncId,
            containerSlot, 0, SlotActionType.PICKUP, p);
    }
}
