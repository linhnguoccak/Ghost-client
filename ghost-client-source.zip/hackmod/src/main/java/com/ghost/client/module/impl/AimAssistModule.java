package com.ghost.client.module.impl;

import com.ghost.client.module.Module;
import com.ghost.client.module.config.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class AimAssistModule extends Module {

    public final Setting<Double> fov = new Setting<>(
        "FOV", "Field of view to search for targets (degrees)", 90.0, 10.0, 180.0);
    public final Setting<Double> speed = new Setting<>(
        "Speed", "How fast to rotate towards target (lower = smoother)", 3.0, 0.5, 10.0);
    public final Setting<Double> range = new Setting<>(
        "Range", "Target range in blocks", 6.0, 1.0, 10.0);
    public final Setting<Boolean> targetPlayers = new Setting<>(
        "Target Players", "Aim at other players", true);
    public final Setting<Boolean> targetMobs = new Setting<>(
        "Target Mobs", "Aim at hostile mobs", false);
    public final Setting<Boolean> onlyWhileHolding = new Setting<>(
        "Only While Attacking", "Only aim while left-click held", false);

    public AimAssistModule() {
        super("AimAssist", "Smoothly rotates towards nearest enemy", Category.COMBAT);
        settings.add(fov);
        settings.add(speed);
        settings.add(range);
        settings.add(targetPlayers);
        settings.add(targetMobs);
        settings.add(onlyWhileHolding);
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;

        Entity target = findTarget();
        if (target == null) return;

        Vec3d eyePos = mc.player.getEyePos();
        Vec3d targetPos = target.getPos().add(0, target.getHeight() * 0.8, 0);
        Vec3d diff = targetPos.subtract(eyePos);

        double dist = diff.horizontalLength();
        double yaw   = Math.toDegrees(Math.atan2(-diff.x, diff.z));
        double pitch = Math.toDegrees(-Math.atan2(diff.y, dist));

        float curYaw   = mc.player.getYaw();
        float curPitch = mc.player.getPitch();

        float deltaYaw   = (float) wrapDegrees(yaw   - curYaw);
        float deltaPitch = (float) wrapDegrees(pitch - curPitch);

        float spd = speed.getValue().floatValue();
        deltaYaw   = clamp(deltaYaw,   -spd, spd);
        deltaPitch = clamp(deltaPitch, -spd, spd);

        mc.player.setYaw(curYaw   + deltaYaw);
        mc.player.setPitch(curPitch + deltaPitch);
    }

    private Entity findTarget() {
        double r = range.getValue();
        Entity best = null;
        double bestDist = Double.MAX_VALUE;
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            if (targetPlayers.getValue() && !(e instanceof PlayerEntity)) continue;
            if (!targetPlayers.getValue() && !targetMobs.getValue()) continue;
            double d = mc.player.distanceTo(e);
            if (d > r) continue;
            if (!isInFov(e)) continue;
            if (d < bestDist) { bestDist = d; best = e; }
        }
        return best;
    }

    private boolean isInFov(Entity e) {
        float half = fov.getValue().floatValue() / 2f;
        Vec3d diff = e.getPos().subtract(mc.player.getPos()).normalize();
        Vec3d look = mc.player.getRotationVector();
        double angle = Math.toDegrees(Math.acos(Math.max(-1, Math.min(1, diff.dotProduct(look)))));
        return angle <= half;
    }

    private double wrapDegrees(double d) {
        d %= 360;
        if (d >= 180) d -= 360;
        if (d < -180) d += 360;
        return d;
    }

    private float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }
}
