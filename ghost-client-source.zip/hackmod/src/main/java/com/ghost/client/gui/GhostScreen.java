package com.ghost.client.gui;

import com.ghost.client.GhostClient;
import com.ghost.client.module.Module;
import com.ghost.client.module.config.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.List;

public class GhostScreen extends Screen {

    // layout constants
    private static final int PANEL_X      = 10;
    private static final int PANEL_Y      = 10;
    private static final int PANEL_W      = 130;
    private static final int MODULE_H     = 14;
    private static final int HEADER_H     = 16;
    private static final int SETTING_H    = 12;
    private static final int CONFIG_X     = 150;
    private static final int CONFIG_W     = 160;

    private Module selectedModule = null;
    private Setting<?> draggingSetting = null;
    private int dragStartX = 0;
    private double dragStartVal = 0;

    public GhostScreen() {
        super(Text.literal("Ghost Client"));
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() {
        super.close();
        GhostClient.getClickGUI().setOpen(false);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // semi-transparent background
        ctx.fill(0, 0, width, height, 0x88000000);

        List<Module> modules = GhostClient.getModuleManager().getModules();

        // --- module list panel ---
        int panelH = HEADER_H + modules.size() * MODULE_H + 4;
        drawPanel(ctx, PANEL_X, PANEL_Y, PANEL_W, panelH);

        // header
        ctx.fill(PANEL_X, PANEL_Y, PANEL_X + PANEL_W, PANEL_Y + HEADER_H, 0xFF1a1a2e);
        ctx.drawCenteredTextWithShadow(textRenderer, "§b§lGHOST", PANEL_X + PANEL_W / 2, PANEL_Y + 4, 0xFFFFFF);

        int my = PANEL_Y + HEADER_H + 2;
        for (Module m : modules) {
            boolean hovered = mouseX >= PANEL_X && mouseX <= PANEL_X + PANEL_W
                && mouseY >= my && mouseY < my + MODULE_H;
            int bg = m.isEnabled()  ? 0xFF16213e
                   : hovered        ? 0xFF2a2a3e
                   :                  0xFF1a1a2e;
            ctx.fill(PANEL_X + 2, my, PANEL_X + PANEL_W - 2, my + MODULE_H - 1, bg);

            // colored dot
            int dot = m.isEnabled() ? 0xFF00e5ff : 0xFF555555;
            ctx.fill(PANEL_X + 5, my + 4, PANEL_X + 10, my + 9, dot);

            // name
            ctx.drawTextWithShadow(textRenderer,
                Text.literal(m.getName()),
                PANEL_X + 14, my + 3, m.isEnabled() ? 0xFFFFFFFF : 0xFF888888);

            my += MODULE_H;
        }

        // --- settings panel ---
        if (selectedModule != null && !selectedModule.getSettings().isEmpty()) {
            int sy = PANEL_Y;
            int sh = HEADER_H + selectedModule.getSettings().size() * SETTING_H + 8;
            drawPanel(ctx, CONFIG_X, sy, CONFIG_W, sh);

            ctx.fill(CONFIG_X, sy, CONFIG_X + CONFIG_W, sy + HEADER_H, 0xFF0f3460);
            ctx.drawCenteredTextWithShadow(textRenderer,
                "§e" + selectedModule.getName(),
                CONFIG_X + CONFIG_W / 2, sy + 4, 0xFFFFFF);

            int ry = sy + HEADER_H + 4;
            for (Setting<?> s : selectedModule.getSettings()) {
                ctx.drawTextWithShadow(textRenderer,
                    Text.literal("§7" + s.getName() + ": §f" + formatValue(s)),
                    CONFIG_X + 6, ry + 1, 0xFFFFFF);

                // slider bar for numeric settings
                if (s.getValue() instanceof Number && s.getMin() != null) {
                    double v   = ((Number) s.getValue()).doubleValue();
                    double lo  = ((Number) s.getMin()).doubleValue();
                    double hi  = ((Number) s.getMax()).doubleValue();
                    int barW = CONFIG_W - 12;
                    int filled = (int)((v - lo) / (hi - lo) * barW);
                    ctx.fill(CONFIG_X + 6, ry + 9, CONFIG_X + 6 + barW, ry + 11, 0xFF333355);
                    ctx.fill(CONFIG_X + 6, ry + 9, CONFIG_X + 6 + filled, ry + 11, 0xFF00e5ff);
                }
                ry += SETTING_H;
            }
        }

        super.render(ctx, mouseX, mouseY, delta);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        List<Module> modules = GhostClient.getModuleManager().getModules();
        int panelH = HEADER_H + modules.size() * MODULE_H + 4;

        // click on module list
        if (mx >= PANEL_X && mx <= PANEL_X + PANEL_W && my >= PANEL_Y + HEADER_H && my <= PANEL_Y + panelH) {
            int idx = (int)(my - PANEL_Y - HEADER_H - 2) / MODULE_H;
            if (idx >= 0 && idx < modules.size()) {
                Module m = modules.get(idx);
                if (button == 0) {
                    m.toggle();
                    GhostClient.getConfigManager().save();
                } else if (button == 1) {
                    selectedModule = (selectedModule == m) ? null : m;
                }
                return true;
            }
        }

        // click on setting slider
        if (selectedModule != null) {
            int ry = PANEL_Y + HEADER_H + 4;
            for (Setting<?> s : selectedModule.getSettings()) {
                if (s.getValue() instanceof Number && s.getMin() != null) {
                    int barY = ry + 9;
                    if (my >= barY - 3 && my <= barY + 5 && mx >= CONFIG_X + 6 && mx <= CONFIG_X + CONFIG_W - 6) {
                        draggingSetting = s;
                        dragStartX = (int) mx;
                        dragStartVal = ((Number) s.getValue()).doubleValue();
                        return true;
                    }
                } else if (s.getValue() instanceof Boolean && button == 0) {
                    if (my >= ry && my < ry + SETTING_H && mx >= CONFIG_X + 6 && mx <= CONFIG_X + CONFIG_W - 6) {
                        s.setValueRaw(!(Boolean) s.getValue());
                        GhostClient.getConfigManager().save();
                        return true;
                    }
                }
                ry += SETTING_H;
            }
        }

        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (draggingSetting != null && draggingSetting.getMin() != null) {
            double lo  = ((Number) draggingSetting.getMin()).doubleValue();
            double hi  = ((Number) draggingSetting.getMax()).doubleValue();
            double barW = CONFIG_W - 12;
            double pct = ((mx - (CONFIG_X + 6)) / barW);
            pct = Math.max(0, Math.min(1, pct));
            double newVal = lo + pct * (hi - lo);
            if (draggingSetting.getValue() instanceof Integer)
                draggingSetting.setValueRaw((int) Math.round(newVal));
            else
                draggingSetting.setValueRaw(Math.round(newVal * 100.0) / 100.0);
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (draggingSetting != null) {
            GhostClient.getConfigManager().save();
            draggingSetting = null;
        }
        return super.mouseReleased(mx, my, button);
    }

    private void drawPanel(DrawContext ctx, int x, int y, int w, int h) {
        // shadow
        ctx.fill(x + 3, y + 3, x + w + 3, y + h + 3, 0x55000000);
        // border
        ctx.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF00e5ff);
        // body
        ctx.fill(x, y, x + w, y + h, 0xEE0d0d1a);
    }

    private String formatValue(Setting<?> s) {
        Object v = s.getValue();
        if (v instanceof Double) return String.format("%.2f", v);
        if (v instanceof Float)  return String.format("%.2f", v);
        return v.toString();
    }
}
