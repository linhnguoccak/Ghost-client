package com.ghost.client.mixin;

import com.ghost.client.GhostClient;
import com.ghost.client.module.impl.HitboxModule;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {

    @Shadow public abstract Box getBoundingBox();

    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
    private void ghost_expandHitbox(CallbackInfoReturnable<Box> cir) {
        HitboxModule hitbox = (HitboxModule) GhostClient.getModuleManager().getByName("Hitbox");
        if (hitbox == null || !hitbox.isEnabled()) return;

        Entity self = (Entity)(Object)this;
        // don't expand local player's own box
        if (self == GhostClient.mc.player) return;

        double expand = hitbox.expandSize.getValue();
        Box original = cir.getReturnValue();
        cir.setReturnValue(original.expand(expand, 0, expand));
    }
}
